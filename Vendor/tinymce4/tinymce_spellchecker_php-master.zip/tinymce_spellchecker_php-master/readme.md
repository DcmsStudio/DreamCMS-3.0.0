TinyMCE - Spellchecker for PHP
===============================

This is the PHP backend for the TinyMCE 4.0 spellchecker plugin. It enables you to use different PHP implementations such as Enchant, Google or PSpell.

How to build TinyMCE Spellchecker for PHP
------------------------------------------

Install Node.JS and Jake globally using npm. Then just run jake to build a release package.

```
npm jake -g
npm install
jake
```

Contributing to the TinyMCE Spellchecker for PHP project
---------------------------------------------------------
You can read more about how to contribute to this project at [http://tinymce.moxiecode.com/contributing](http://tinymce.moxiecode.com/contributing)
