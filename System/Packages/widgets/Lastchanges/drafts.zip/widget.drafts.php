<?php

class DraftsWidget extends Widget
{

    public function DraftsWidget($id)
    {
        Widget::getUserConfig($id);
    }

    public function getWidgetConfig(&$data)
    {
        exit;
    }

    public function getError()
    {

    }

    public function getData()
    {
        $db = DB::getInstance();

        $sql = "SELECT d.*, u.username FROM %tp%drafts AS d
				LEFT JOIN %tp%users AS u ON(u.userid=d.userid) 
				ORDER BY `timestamp` DESC";
        $data = $db->query($sql)->fetchAll();
		
		foreach ($data as $idx => $r)
		{
			$data[$idx]['date'] = date('d.m.Y, H:i:s', $r['timestamp']);
		}
		
		
		
		
        $rs = array();
        $rs['drafts'] = $data;

        return self::out('drafts', $rs);
    }

}

?>