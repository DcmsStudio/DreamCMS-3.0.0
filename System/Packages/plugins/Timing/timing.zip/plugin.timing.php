<?php

class TimingPlugin extends Plugin
{

    public $is_runnable = true;
    public $is_configurable = false;

    public function run()
    {
        $data = array();

        return $this->renderTemplate($data, 'run');
    }

    public function onBeforeOutput(&$data, &$object)
    {

        $time = sprintf("%2.4f s", (microtime(true) - START));
        if (function_exists('memory_get_peak_usage'))
        {
            $time .= ' <small>(peak:' . Library::humanSize(memory_get_peak_usage(true)) . ' usage:' . Library::humanSize(memory_get_usage()) . ')</small>';
        }

        $data = str_replace('<!--TIMING-->', $time, $data);
		
		return $data;
    }

    public function onBeforeRender(&$data, &$object)
    {
        $time = sprintf("%2.4f s", (microtime(true) - START));
        if (function_exists('memory_get_peak_usage'))
        {
            $time .= ' <small>(peak:' . Library::humanSize(memory_get_peak_usage(true)) . ' usage:' . Library::humanSize(memory_get_usage()) . ')</small>';
        }

        $data = str_replace('<TIMING>', $time, $data);
		
		return $data;
    }

    public function onBeforeRunController(&$data, &$object)
    {
        $time = sprintf("%2.4f s", (microtime(true) - START));
        if (function_exists('memory_get_peak_usage'))
        {
            $time .= ' <small>(peak:' . Library::humanSize(memory_get_peak_usage(true)) . ' usage:' . Library::humanSize(memory_get_usage()) . ')</small>';
        }

        $data = str_replace('<TIMING>', $time, $data);
		
		return $data;
    }

}

?>