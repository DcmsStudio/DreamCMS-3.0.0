<?php
/**
 * DreamCMS Open Source CMS
 * Copyright (C) 2007-2011 Marcel Domke
 *
 *
 * This program is free software: you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation, either
 * version 3 of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU
 * Lesser General Public License for more details.
 * 
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * PHP version 5
 * @copyright  Marcel Domke 2007-2011
 * @author     Marcel Domke <http://www.dreamcms.de>
 * @package    LocaleselectPlugin
 * @license    GPL
 * @filesource
 */
class LocaleselectPlugin extends Plugin
{

    public $is_runnable = true;
    public $is_configurable = false;

    public function run()
    {
        $data = array();
		
		$data['guilocales'] = $this->db->query('SELECT * FROM %tp%locale WHERE guilanguage = 1 ORDER BY title')->fetchAll();
		
		foreach($data['guilocales'] as $idx => $r)
		{	
			$r['location'] = 'index.php?setlocale='.$r['code'];
			$r['icon'] = HTML_URL.'img/flags/'.$r['flag'];
			$data['guilocales'][$idx] = $r;
		}
        return $this->renderTemplate($data, 'run');
    }
}

?>