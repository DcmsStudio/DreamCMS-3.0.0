<?php

class TestPluginInstaller
{

    public static function install()
    {
        //die('installer stuff here');
    }

    public static function uninstall()
    {

    }

}

?>